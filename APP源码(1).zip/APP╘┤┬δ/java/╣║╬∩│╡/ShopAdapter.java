package cn.itcast.shoppingactivity;


import android.widget.ImageView;
import android.widget.TextView;

public class ShopAdapter {

    TextView title,price;
    ImageView iv;
}
