package cn.itcast.shoppingactivity.utils;

public class DBUtils {
    public static final String DATABASE_NAME="ShopMall";//数据库名
    public static final String DATABASE_TABLE="Shop";  //表名
    public static final int DATABASE_VERION=1;         //数据库版本
    //数据库表的列名
    public static final String Shop_ID="id";
    public static final String Shop_name="name";
    public static final String Shop_price="price";


}
