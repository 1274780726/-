package cn.itcast.shoppingactivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import cn.itcast.shoppingactivity.bean.ShopBean;

public class shoppingActivity extends AppCompatActivity implements View.OnClickListener
{
   ImageView gw;
    private ListView mListView;
    private int[] id={1,2,3,4,5,6,7,8,9,10};
    private String[] titles={
            "正品匡1970S高低帮帆布鞋女鞋男经典款三星标",
            "匡威官方 经典款 休闲男女鞋 情侣鞋 101010",
            "高筒休闲板鞋 166516C/167278C",
            "官方 Converse x JWA Runstar Hybrid 高帮 164665C",
            "AllStar新款男女情侣百搭休闲帆布鞋",
            "官方NIKE AIR MAX 270 REACT男子运动鞋AO4971 ",
            "官方NIKE TANJUN男子运动鞋休闲鞋812654",
            "纽约时装周走秀同款重燃ACE 2020女鞋时尚中帮运动鞋",
            "跑步鞋男鞋2020新款星耀减震回弹跑鞋男士低帮运动鞋",
            "男鞋跑步鞋2019冬季新款减震跑鞋秋季断码休闲鞋超轻运动鞋子"
    };
    private  String[] prices={
            "¥168","¥438","¥228","¥338","¥999","¥1018","¥1018","¥888","¥899","¥520"
    };
    private int[] icons={R.drawable.shoes_one,R.drawable.shoes_two,R.drawable.shoes_three,R.drawable.shoes_four,R.drawable.shoes_five,R.drawable.shoes_six,
            R.drawable.shoes_seven,R.drawable.shoes_eig,R.drawable.shoes_nine,R.drawable.shoes_ten};
    List<ShopBean> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shoppingmall);
        mListView=(ListView)findViewById(R.id.lv);
        gw=(ImageView) findViewById(R.id.gwc_1);
        gw.setOnClickListener(this);
        MyBaseAdapter mAdapter = new MyBaseAdapter();
        mListView.setAdapter(mAdapter);
        CilckItem();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){


            case  R.id.gwc_1:
                Intent int1=new Intent(this,ShopCar.class);
                startActivity(int1);
                break;
        }
    }

    class MyBaseAdapter extends BaseAdapter  {
        @Override
        public int getCount(){
            return titles.length;
        }
        @Override
        public Object getItem(int position){
            return titles[position];
        }
        @Override
        public long getItemId(int position){
            return position;
        }
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ShopAdapter holder ;
            if (convertView == null) {
                convertView = View.inflate(shoppingActivity.this, R.layout.list_item, null);
                holder = new ShopAdapter();
                holder.title = (TextView) convertView.findViewById(R.id.title);
                holder.price = (TextView) convertView.findViewById(R.id.price);
                holder.iv = (ImageView) convertView.findViewById(R.id.iv);
                convertView.setTag(holder);
            } else {
                holder = (ShopAdapter) convertView.getTag();
            }
            holder.title.setText(titles[position]);
            holder.price.setText(prices[position]);
            holder.iv.setBackgroundResource(icons[position]);
            return convertView;
        }
    }
    protected void CilckItem(){
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent=new Intent(shoppingActivity.this,Content.class);
                intent.putExtra("name",titles[position]);
                intent.putExtra("price",prices[position]);
                intent.putExtra("picture",icons[position]);

                startActivity(intent);
            }
        });
    }
}
